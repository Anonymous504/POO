/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estado.de.resultados;
import java.util.Scanner;
/**
 *
 * @author Joseph Andino
 */
public class EstadoDeResultados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int ventas,costventa,ubruta,gasopera,uopera,oproductos,ogastos,anisrptu,isr,ptu,uneta;
    Scanner sc = new Scanner(System.in);
    
        System.out.println("----- JH COMERCIALIZADORA S.A -----");
        System.out.println("Ingrese el valor de las ventas: ");
        ventas = sc.nextInt();
        System.out.println("Ingrese el costo de las ventas: ");
        costventa = sc.nextInt();
        ubruta=ventas-costventa;
        System.out.println("Ingrese el valor de los gastos de operacion:");
        gasopera = sc.nextInt();
        uopera = ubruta-gasopera;
        System.out.println("Ingrese el valor de otros productos:");
        oproductos = sc.nextInt();
        System.out.println("Ingrese el valor de otros gastos:");
        ogastos = sc.nextInt();
        anisrptu = (uopera+oproductos) - ogastos;
        System.out.println("Ingrese el valor del impuesto sobre la renta ISR: ");
        isr = sc.nextInt();
        System.out.println("Ingrese el valor de participacion de los trabajadores en las utilidades PTU");
        ptu = sc.nextInt();
        uneta = (anisrptu-isr-ptu);
        
        
        
        System.out.println("                 JH COMERCIALIZADORA S.A                      ");
        System.out.println("Estado de resultados del 1 de enero al 31 de Diciembre de 2016");
        System.out.println("------------------------------------------------------------------");
        System.out.println("Ventas                                                        "+ventas);
        System.out.println("Costo de ventas                                              -"+costventa);
        System.out.println("                                                            -----------");
        System.out.println("UTILIDAD BRUTA                                                "+ubruta);
        System.out.println("Gastos de operacion                                          -"+gasopera);
        System.out.println("                                                            -----------");
        System.out.println("UTILIDAD EN OPERACION                                         "+uopera);
        System.out.println("Otros productos                                               "+oproductos);
        System.out.println("Otros gastos                                                 -"+ogastos);
        System.out.println("                                                             -----------");
        System.out.println("UTILIDAD ANTES DE ISR Y PTU                                   "+anisrptu);
        System.out.println("Impuesto sobre la renta (ISR) 28%                            -"+isr);
        System.out.println("Participacion de los trabajadores en las utilidades (PTU)    -"+ptu);
        System.out.println("                                                             -----------");
        System.out.println("UTILIDAD NETA                                                 "+uneta);
        
        
    
    }
    
}
