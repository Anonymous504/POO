/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tipo.de.triangulo;

/**
 *
 * @author Joseph Andino
 */
import java.io.*;
import java.util.Scanner;
public class TipoTriangulos {
  
   public static void main(String[] args) {
      
       Scanner sc = new Scanner(System.in);
       double lado1,lado2,lado3;
       System.out.print("Introduzca el Valor Numerico del 1 Lado:");
       lado1 = sc.nextDouble();
       System.out.print("Introduzca el Valor Numerico del 2 Lado:");
       lado2 = sc.nextDouble();
       System.out.print("Introduzca el Valor Numerico del 3 Lado:");
       lado3 = sc.nextDouble();
       
       
       if (lado1==lado2 && lado2==lado3)
               System.out.println("El Triangulo es Equilatero");
               else
               {
                       if (lado1==lado2 || lado1==lado3 || lado2==lado3)
                               System.out.println("El Triangulo es Isoceles");
                               else
                               {
                                       if (lado1!=lado2 || lado1!=lado3 || lado3!=lado2)
                                               System.out.println("El Triangulo es Escaleno");
                               }
               }
   }
  
}