/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package par.o.impar;

import java.util.Scanner;

/**
 *
 * @author Joseph Andino
 */
public class ParOImpar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    int numero;
        Scanner sc = new Scanner( System.in );

        System.out.printf( "Introduzca un número entero: " );
        numero = sc.nextInt();

        if ( numero % 2 == 0 )
        {
            System.out.println( "ES PAR" );
        }
        else
        {
            System.out.println( "ES IMPAR" );
            
        }
        
       
          
    }
    
}
