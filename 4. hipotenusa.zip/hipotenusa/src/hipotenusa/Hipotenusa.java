/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hipotenusa;

import java.util.Scanner;

/**
 *
 * @author Joseph Andino
 */
public class Hipotenusa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        double hipo;
        Scanner sc=new Scanner(System.in);
        
        
        System.out.println("ingrese el primer cateto: ");
        double a=sc.nextDouble();  
        System.out.println("ingrese el segundo cateto: ");
        double b=sc.nextDouble(); 
        hipo=Math.sqrt((a*a+b*b));
        System.out.println("La hipotenusa es: "+hipo);    
        
    }
    
}
