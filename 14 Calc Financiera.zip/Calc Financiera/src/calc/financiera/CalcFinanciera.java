/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calc.financiera;

import java.util.Scanner;

/**
 *
 * @author LAB-A2
 */
public class CalcFinanciera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   
        Scanner sc = new Scanner(System.in);
        int meses=0;
        double cuota=0;
    
        System.out.println("Ingrese la cantidad de meses a ahorrar:");
        meses=sc.nextInt();
        System.out.println("Ingrese el valor de la cuota mensual:");
        cuota=sc.nextDouble();
        
        
        for (int i=1; i<=meses; i++){
            System.out.println("Mes "+i+" "+(i*cuota));
            
            
        }
    
    }
    
}
