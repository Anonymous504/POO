/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversiones.kg.gm.lbs;

import java.util.Scanner;

/**
 *
 * @author jvalladares
 */
public class ConversionesKGGMLBS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   char resp;
   int op=0;
   double kg,grm,lbs,toneladas,convert;
   Scanner sc = new Scanner(System.in);
    
   do {
        System.out.println("------ TABLA DE CONVERSIONES ------");
        System.out.println("1. Convertir Kilogramos a Gramos");
        System.out.println("2. Convertir Kilogramos a Libras");
        System.out.println("3. Convertir Toneladas a Kilogramos");
        System.out.println("Seleccione una opcion:");
        op = sc.nextInt();
        
        switch(op){
            
            case 1:
                System.out.println("Ingrese la cantidad de Kilogramos: "); 
                kg = sc.nextDouble();
                convert = (kg*1000);
                System.out.println("Hay "+convert+" Gramos");
                break;
            
            case 2:
                System.out.println("Ingrese la cantidad de Kilogramos:");
                kg = sc.nextDouble();
                convert = (kg*2.20462);
                System.out.println("Hay "+convert+" Libras");
                break;
                
            case 3:
                System.out.println("Ingrese la cantidad de Toneladas:");
                toneladas = sc.nextDouble();
                convert = (toneladas*1000);
                System.out.println("Hay "+convert+" Kilogramos");
                break;
                default:
                 System.out.println("Opcion incorrecta");
                 break;
        }
        System.out.println("Desea realizar otra conversion s/n");
        resp=sc.next().charAt(0);
   }
   while(resp!='n');
   
    }
    
}
