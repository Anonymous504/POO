/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menor.y.mayor.pkg3.numeros;

import java.util.Scanner;

/**
 *
 * @author Joseph Andino
 */
public class MenorYMayor3Numeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
            Scanner entrada=new Scanner(System.in);
            int n1,n2,n3,mayor,menor;
        
        
        System.out.print("Ingrese el primer numero: ");
        n1=entrada.nextInt();
        System.out.print("Ingrese el segundo numero: ");
        n2=entrada.nextInt();
        System.out.print("Ingrese el tercer numero: ");
        n3=entrada.nextInt();
   
        
     
        //numero mayor
        mayor=n1;
        if(n2>mayor)
            mayor=n2;
        if(n3>mayor)
            mayor=n3;
        //numero menor
        menor=n1;
        if(n2<menor)
            menor=n2;
        if(n3<menor)
            menor=n3;      
         
        System.out.println("El numnero mayor es: "+mayor);
        System.out.println("El numero menor es: "+menor);
        
    }
    
}
