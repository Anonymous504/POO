/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculo.de.areas;
import java.util.Scanner;
/**
 *
 * @author Joseph Andino
 */
public class CalculoDeAreas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int base,altura,lado,rec,cubo,cuadro;
    Scanner sc = new Scanner(System.in);
    
        System.out.println("----------- PROGRAMA QUE CALCULA EL AREA DE UN RECTANGULO, CUADRADO Y CUBO ----------");     
        System.out.println("Ingrese cuanto mide la base para calcular el area de un rectangulo y un cuadrado:");
        base = sc.nextInt();
        System.out.println("Ingrese cuanto mide la altura para calcular el area de un rectangulo y un cuadrado:");
        altura = sc.nextInt();
        System.out.println("Ingrese cuanto mide uno de los lados de un cubo para calcular su area:");
        lado = sc.nextInt();
        
        rec = (base*altura)/2;
        cuadro = base*altura;
        cubo = (6*lado*lado);
        
        System.out.println("--------------------------- RESULTADOS -----------------------------");
        System.out.println("El area de un rectangulo con los datos ingresados es de :"+rec);
        System.out.println("El area de un cuadrado con los datos ingresados es de :"+cuadro);
        System.out.println("El area de un cubo con los datos ingresados es de :"+cubo);
        
        
    }
    
}
