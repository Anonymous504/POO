/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu_telefonia_movil;
import java.util.Scanner;
/**
 *
 * @author LAB-A2
 */
public class Menu_Telefonia_Movil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
     String numeroCuenta = "87394283";
     double saldoprincipal = 500;
     double datosnavega = 10000;
     double SMS = 200;
     double prestamo = 0;
     int resp = 0;
     double monto=0;
     
      while(resp != -1){
            System.out.println("---- Bienvenido a Menú Claro ---- ");
            System.out.println(" 1. Consulta de saldo  "); 
            System.out.println(" 2. Transferir Saldo ");
            System.out.println(" 3. Solicitar Prestamo de Saldo");
            System.out.println("-1. Salir ");
            System.out.println(" Que desea realizar... ? ");
            resp = sc.nextInt(); 
      
            switch(resp){
                case 1:
                    System.out.println("");
                    System.out.println("----------------------------------------");
                    System.out.println("Su Saldo Principal es de: "+saldoprincipal+" Lps.");
                    System.out.println("Su Datos de Navegación disponibles son: "+datosnavega+" MB");
                    System.out.println("Tiene: "+SMS+"SMS");
                    System.out.println("----------------------------------------");
                    System.out.println("Saldo Disponible...   "+saldoprincipal);
                    System.out.println("----------------------------------------");
                    System.out.println("Saldo en Prestamnos....  "+prestamo);
                    break;
                    
                 case 2: 
                   System.out.println("Su Saldo Principal es de: "+saldoprincipal+" Lps.");
                   System.out.println("Ingrese el monto a transferir... ");
                   monto = sc.nextDouble();
                    if (saldoprincipal>monto){
                        saldoprincipal = saldoprincipal-monto;
                    }else{
                        System.err.println("No tiene saldo disponible");
                        resp = 0;
                    }
                    break;
                  
                 case 3: 
                    System.out.println("----------------------------------------");
                    System.out.println("Solicitud de Prestamo de Saldo #"+numeroCuenta);
                    System.out.println("Ingrese el monto requerido... ");
                    monto = sc.nextDouble();
                    
                    saldoprincipal = (saldoprincipal+monto);
                    prestamo = monto;
                  break;
                default: 
                        resp = 0;
            }
            System.out.println("");
            System.out.println(" ===================================================  "); 
            System.out.println(" Presione -1 para salir, 0 para volver al menu ");
            resp = sc.nextInt();
      
    }

    }
}