package vocaloconsonante;

import java.util.Scanner;


public class VocalOconsonante {

    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);// instanciar un objeto
        String  letra = "";
        int contador= 0;
        int contador2=0;
               for (int i=0; i<5; i++){
        System.out.println("Ingrese una letra");
        letra = entrada.nextLine();
        
        if (letra.equals("A")||letra.equals("E")||letra.equals("I")||letra.equals("O")||letra.equals("U")||letra.equals("a")||letra.equals("e")||letra.equals("i")||letra.equals("o")||letra.equals("u")){
        contador++;
        
             }
        else {
         contador2++;   
        }
        }
               System.out.println("El total de vocales es: "+contador);
               System.out.println("El total de consonantes es: "+contador2);
}
}
