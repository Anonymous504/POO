/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operaciones.basicas;
import java.io.InputStream;
import java.util.Scanner;
/**
 *
 * @author Joseph Andino
 */
public class OperacionesBasicas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int a,b,sum,res,multi,div;
    Scanner sc = new Scanner(System.in);
    
        System.out.println(" ------Programa que realiza las 4 operaciones basicas ------");
        System.out.println("Ingrese el primer numero entero:");
        a = sc.nextInt();
        System.out.println("Ingrese el segundo numero entero:");
        b = sc.nextInt();
        
        sum = a+b;
        res = a-b;
        multi = a*b;
        div = a/b;
        
        System.out.println("------- RESULTADOS-------");
        System.out.println("La suma es igual a: "+sum);
        System.out.println("La resta es igual a: "+res);
        System.out.println("L multiplicacion es igual a: "+multi);
        System.out.println("La division es igual a: "+div);
        
    
    }
    
    
}
