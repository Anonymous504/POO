/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sueldo.empleado;
import java.util.Scanner;
/**
 *
 * @author jvalladares
 */
public class SueldoEmpleado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    double horas,sueldo,pagoxhora;
    Scanner sc = new Scanner(System.in);
    
        System.out.println("Ingrese la cantidad de horas trabajadas: ");
        horas = sc.nextDouble();
        System.out.println("Ingrese el pago por hora laborada: ");
        pagoxhora = sc.nextDouble();
        
        if(horas > 40){
        //calcula el salario de las primeras 40 horas
        double primerashoras = 40 * pagoxhora;
        double preciohoraextra = (pagoxhora/2)+pagoxhora;
        //calcula el salario de las horas extra
        double salarioHorasExtra = (horas - 40) * preciohoraextra;

        sueldo = primerashoras + salarioHorasExtra;//suma las dos cantidades
    }
    else{
        //menos de 40 horas trabajadas
        sueldo = pagoxhora * horas;
    }

    System.out.println("El salario es: " + sueldo);
    
                    
                
    
    
    }
    
    
}
