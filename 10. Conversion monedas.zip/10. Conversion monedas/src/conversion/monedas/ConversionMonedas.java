/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversion.monedas;
import java.util.Scanner;
/**
 *
 * @author jvalladares
 */
public class ConversionMonedas {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
    double dolar,euro,quetzal,bitcoin,lps;
            int op=0;
    Scanner sc = new Scanner (System.in);
    char resp;
    
    
     do{System.out.println("---------------- CASA DE CAMBIO---------------------");
        System.out.println("Seleccione la moneda que quiere convertir a lempiras");
        System.out.println("1. Dolares ");
        System.out.println("2. Euros ");
        System.out.println("3. Quetzales ");
        System.out.println("4. Bitcoins ");
         System.out.println("Seleccione una opcion: ");
        op = sc.nextInt();
    
    switch(op){
    
        case 1:
            System.out.println("Ingrese la cantidad de dolares: ");
            dolar = sc.nextInt();
            lps = (dolar * 24.82);
            System.out.println(dolar +" Dolares equivalen a: "+lps+" Lps.");
    break;
        
    case 2:
            System.out.println("Ingrese la cantidad de Euros: ");
            euro = sc.nextInt();
            lps = (euro * 27.54);
            System.out.println(euro +" Euros equivalen a: "+lps+" Lps.");
    break;
    
     case 3:
            System.out.println("Ingrese la cantidad de Quetzales: ");
            quetzal = sc.nextInt();
            lps = (quetzal * 3.24);
            System.out.println(quetzal +" Quetzales equivalen a: "+lps+" Lps.");
    break;
     
    case 4:
            System.out.println("Ingrese la cantidad de Bitcoins: ");
            bitcoin = sc.nextInt();
            lps = (bitcoin * 232082.39);
            System.out.println(bitcoin +" Bitcoins equivalen a: "+lps+" Lps.");
    break;
    
    default:
        System.out.println("Opcion no valida");
        break;
      
   }
       
     System.out.println("Dese realizar otra conversion s/n");
     resp =sc.next().charAt(0);
     }
      while(resp!='n');
    }
      }


