/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package promedio.pkg5.numeros;
import java.util.Scanner;
/**
 *
 * @author jvalladares
 */
public class Promedio5Numeros {
   /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     int n1,n2,n3,n4,n5,prom;
      Scanner sc = new Scanner(System.in); 
      
      
        System.out.println("----- PROMEDIO DE 5 NUMEROS -----");
        System.out.print("Ingrese el primer numero:");
        n1 = sc.nextInt();
        System.out.print("Ingrese el segundo numero:");
        n2 = sc.nextInt();
        System.out.print("Ingrese el tercer numero:");
        n3 = sc.nextInt();
        System.out.print("Ingrese el cuarto numero:");
        n4 = sc.nextInt();
        System.out.print("Ingrese el quinto numero:");
        n5 = sc.nextInt();
        
        prom = (n1+n2+n3+n4+n5)/5;
        
        System.out.println("El promedio de los numeros ingresados es de: "+prom);
    
    
    }
    
}
